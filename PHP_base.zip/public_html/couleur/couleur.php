<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");
/*
$results["error"] = false;
$results["message"] = [];*/

if(isset($_POST)){

	$sql = $db->prepare("SELECT * FROM couleurs");
	$sql->execute();
	$row = $sql->fetchall(PDO::FETCH_OBJ);

	foreach($row as $i) {
		$results[$i->id_couleur] = $i->libelle;
	}

	echo json_encode($results);

}

?>