<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

$results["error"] = false;
$results["message"] = [];

// Données tests pour l'inscription
/*$_POST['id_joueur1'] = '7';
$_POST['id_joueur2'] = '1';*/

if(isset($_POST)){

	if(!empty($_POST['id_joueur1']) && !empty($_POST['id_joueur2'])){

		$id_joueur1 = $_POST['id_joueur1'];
		$id_joueur2 = $_POST['id_joueur2'];

		$sql = $db->prepare("INSERT INTO duel(id_joueur1, id_joueur2, score_joueur1, score_joueur2) VALUES(:id_joueur1, :id_joueur2, 0, 0)");
		$sql->execute([":id_joueur1" => $id_joueur1, ":id_joueur2" => $id_joueur2]);

		if(!$sql){
			$results["error"] = true;
			$results["message"] = "Erreur lors de l'inscription";
		}

	} else {
		$results["error"] = true;
		$results["message"] = "Veuillez remplir tout les champs";
	}

	echo json_encode($results);

}

?>