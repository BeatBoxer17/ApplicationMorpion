<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

//$_POST['id'] = 1;

if(isset($_POST)){

	$id = $_POST['id'];

	$sql = $db->prepare("SELECT users.id, users.pseudo 
						FROM users 
						WHERE users.id NOT IN(SELECT duel.id_joueur1
					                        FROM duel, users
					                        WHERE duel.id_joueur2 = users.id
					                        AND users.id = :id
					                        UNION
					                        SELECT duel.id_joueur2
					                        FROM duel, users
					                        WHERE duel.id_joueur1 = users.id
                        					AND users.id = :id)
						AND users.id != :id");
	$sql->execute([":id" => $id]);
	$row = $sql->fetchall(PDO::FETCH_OBJ);

	foreach($row as $i) {
		$results[$i->id] = $i->pseudo;
	}

	echo json_encode($results);

}

?>