<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

/*$_POST['idj1'] = "2";
$_POST['idj2'] = "8";
$_POST['v'] = "2";*/

if(isset($_POST)){

	$idj1 = $_POST['idj1'];
	$idj2 = $_POST['idj2'];
	$v = $_POST['v'];


	$sql1 = $db->prepare("SELECT * FROM duel WHERE id_joueur1 = :idj1 AND id_joueur2 = :idj2");
	$sql1->execute([":idj1" => $idj1, ":idj2" => $idj2]);
	$row = $sql1->fetch(PDO::FETCH_OBJ);


	if($row){
		echo "sql1";
		if ($v == $idj1) {
			$sql = $db->prepare("UPDATE duel SET score_joueur1 = score_joueur1 + 1 WHERE id_joueur1 = :idj1 AND id_joueur2 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
		}
		if ($v == $idj2) {
			$sql = $db->prepare("UPDATE duel SET score_joueur2 = score_joueur2 + 1 WHERE id_joueur1 = :idj1 AND id_joueur2 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
		}
	} 

	$sql2 = $db->prepare("SELECT * FROM duel WHERE id_joueur1 = :idj2 AND id_joueur2 = :idj1");
	$sql2->execute([":idj1" => $idj1, ":idj2" => $idj2]);
	$row2 = $sql2->fetch(PDO::FETCH_OBJ);

	if($row2) {
		echo "sql2";
		if ($v == $idj1) {
			$sql = $db->prepare("UPDATE duel SET score_joueur2 = score_joueur2 + 1 WHERE id_joueur2 = :idj1 AND id_joueur1 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
		}
		if ($v == $idj2) {
			$sql = $db->prepare("UPDATE duel SET score_joueur1 = score_joueur1 + 1 WHERE id_joueur2 = :idj1 AND id_joueur1 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
		}
	}
	

	echo json_encode($results);

}

?>