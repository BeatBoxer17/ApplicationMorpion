<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

/*$_POST['idj1'] = "8";
$_POST['idj2'] = "2";
$_POST['idinfo'] = "8";*/

if(isset($_POST)){

	$idj1 = $_POST['idj1'];
	$idj2 = $_POST['idj2'];
	$idinfo = $_POST['idinfo'];


	$sql1 = $db->prepare("SELECT * FROM duel WHERE id_joueur1 = :idj1 AND id_joueur2 = :idj2");
	$sql1->execute([":idj1" => $idj1, ":idj2" => $idj2]);
	$row = $sql1->fetch(PDO::FETCH_OBJ);


	if($row){
		if ($idinfo == $idj1) {
			$sql = $db->prepare("SELECT score_joueur1, id_couleur FROM users, duel WHERE users.id = duel.id_joueur1 AND id_joueur1 = :idj1 AND id_joueur2 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
			$row = $sql->fetchall(PDO::FETCH_OBJ);

			foreach ($row as $i) {
				$results["score"] = $i->score_joueur1;
				$results["couleur"] = $i->id_couleur;
			}
		}
		if ($idinfo == $idj2) {
			$sql = $db->prepare("SELECT score_joueur2, id_couleur FROM users, duel WHERE users.id = duel.id_joueur2 AND id_joueur1 = :idj1 AND id_joueur2 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
						$row = $sql->fetchall(PDO::FETCH_OBJ);

			foreach ($row as $i) {
				$results["score"] = $i->score_joueur2;
				$results["couleur"] = $i->id_couleur;
			}
		}
	} 

	$sql2 = $db->prepare("SELECT * FROM duel WHERE id_joueur1 = :idj2 AND id_joueur2 = :idj1");
	$sql2->execute([":idj1" => $idj1, ":idj2" => $idj2]);
	$row2 = $sql2->fetch(PDO::FETCH_OBJ);

	if($row2) {
		if ($idinfo == $idj1) {
			$sql = $db->prepare("SELECT score_joueur2, id_couleur FROM users, duel WHERE users.id = duel.id_joueur2 AND id_joueur2 = :idj1 AND id_joueur1 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
						$row = $sql->fetchall(PDO::FETCH_OBJ);

			foreach ($row as $i) {
				$results["score"] = $i->score_joueur2;
				$results["couleur"] = $i->id_couleur;
			}
		}
		if ($idinfo == $idj2) {
			$sql = $db->prepare("SELECT score_joueur1, id_couleur FROM users, duel WHERE users.id = duel.id_joueur1 AND id_joueur2 = :idj1 AND id_joueur1 = :idj2");
			$sql->execute([":idj1" => $idj1, ":idj2" => $idj2]);
						$row = $sql->fetchall(PDO::FETCH_OBJ);

			foreach ($row as $i) {
				$results["score"] = $i->score_joueur1;
				$results["couleur"] = $i->id_couleur;
			}
		}
	}
	

	echo json_encode($results);

}

?>