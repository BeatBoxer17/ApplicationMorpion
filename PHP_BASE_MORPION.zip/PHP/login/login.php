<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

$results["error"] = false;
$results["message"] = [];

if(!empty($_POST)){

	if(!empty($_POST['pseudo']) && !empty($_POST['password'])){

		$pseudo = $_POST['pseudo'];
		$password = $_POST['password'];

		$sql = $db->prepare("SELECT * FROM users WHERE pseudo = :pseudo");
		$sql->execute([':pseudo' => $pseudo]);
		$row = $sql->fetch(PDO::FETCH_OBJ);

		if($row){
			if(password_verify($password, $row->password)){

				$results['error'] = false;
				$results['id'] = $row->id;
				$results['pseudo'] = $row->pseudo;
				$results['id_couleur'] = $row->id_couleur;

			} else {

				$results['error'] = true;
				$results['message'] = "Pseudo ou mot de passe incorrect";

			}
		} else {

			$results['error'] = true;
			$results['message'] = "Pseudo ou mot de passe incorrect";

		}



	} else {

		$results['error'] = true;
		$results['message'] = "Veuillez remplir tout les champs";

	}

	echo json_encode($results);
	
}

?>