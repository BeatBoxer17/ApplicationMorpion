<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

if(isset($_POST)){

	$sql = $db->prepare("SELECT * FROM couleurs");
	$sql->execute();
	$row = $sql->fetchall(PDO::FETCH_OBJ);

	if($row){
		foreach($row as $i) {
			$results[$i->id_couleur] = $i->libelle;
		}
	} else {
		$results["error"] = true;
		$results["message"] = "Erreur pour récuperer les couleurs";
	}

	echo json_encode($results);

}

?>