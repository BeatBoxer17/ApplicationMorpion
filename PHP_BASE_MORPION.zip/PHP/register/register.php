<?php

$db = new PDO("mysql:host=localhost;dbname=id5745927_morpion","id5745927_valentin","74824419");

$results["error"] = false;
$results["message"] = [];

// Données tests pour l'inscription
/*$_POST['nom'] = 'LARAGRDE';
$_POST['prenom'] = 'Jason';
$_POST['pseudo'] = 'Jasonlgrd';
$_POST['email'] = 'jason@jason.fr';
$_POST['password'] = 'RICHER';
$_POST['password2'] = 'RICHER';
$_POST['id_couleur'] = '1';*/

if(isset($_POST)){

	if(!empty($_POST['pseudo']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['password2']) && !empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['id_couleur'])){

		$pseudo = $_POST['pseudo'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$password2 = $_POST['password2'];
		$nom = $_POST['nom'];
		$prenom = $_POST['prenom'];
		$id_couleur = $_POST['id_couleur'];

		// Verification du pseudo
		if(strlen($pseudo) <2 || !preg_match("/^[a-zA-Z0-9 _-]+$/", $pseudo) || $pseudo > 60){
			$results["error"] = true;
			$results["message"]["pseudo"] = "Pseudo invalide";
		} else {
			$requete = $db->prepare("SELECT id FROM users WHERE pseudo = :pseudo");
			$requete->execute([':pseudo' => $pseudo]);
			$row = $requete->fetch();
			if($row){
				$results["error"] = true;
				$results["message"]["pseudo"] = "Le pseudo est déjà pris";
			}
		}

		// Verification Nom
		if(strlen($nom) <2 || !preg_match("/^[a-zA-Z -]+$/", $nom) || $nom > 60){
			$results["error"] = true;
			$results["message"]["nom"] = "Nom invalide";
		}

		// Verification Prenom
		if(strlen($prenom) <2 || !preg_match("/^[a-zA-Z -]+$/", $prenom) || $prenom > 60){
			$results["error"] = true;
			$results["message"]["prenom"] = "Prenom invalide";
		}

		// Verification du pseudo
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$results["error"] = true;
			$results["message"]["email"] = "Email invalide";
		} else {
			$requete = $db->prepare("SELECT id FROM users WHERE email = :email");
			$requete->execute([':email' => $email]);
			$row = $requete->fetch();
			if($row){
				$results["error"] = true;
				$results["message"]["email"] = "L'email existe déjà";
			}
		}

		// Verification passwords
		if($password != $password2){
			$results["error"] = true;
			$results["message"]["password"] = "Passwords non identiques";
		}

		if($results["error"] == false){

			$password = password_hash($password, PASSWORD_BCRYPT);

			$sql = $db->prepare("INSERT INTO users(nom, prenom, pseudo, email, password, id_couleur) VALUES(:nom, :prenom, :pseudo, :email, :password, :id_couleur)");
			$sql->execute([":nom" => $nom, ":prenom" => $prenom, ":pseudo" => $pseudo, ":email" => $email, ":password" => $password, ":id_couleur" => $id_couleur]);

			if(!$sql){
				$results["error"] = true;
				$results["message"] = "Erreur lors de l'inscription";
			}

		}

	} else {
		$results["error"] = true;
		$results["message"] = "Veuillez remplir tout les champs";
	}

	echo json_encode($results);

}

?>